# VisualStudio_StudyWork
github 주소: https://github.com/DAnomaly/VisualStudio_StudyWork

## ProjectName: 02-photoviewer
1. 기본적인 Dialog 사용법
2. openFileDialog 사용법
3. colorDialog 사용법
4. 프로그램 종료(close())

## ProjectName: 03-mathquiz
1. Timer 사용법
2. 여러개의 버튼의 이벤트를 하나로 물리는 법
   2-1. as 사용
   2-2. equals 사용
3. Color 클래스와 SystemColor 클래스
4. MessageBox.Show(내용,제목);
5. Random 클래스

## ProjectName: 04-matchgame
1. Webdings 폰트
2. TableLayoutPanel - SellBorderStyle
3. Layout안에 있는 모든 Controls(Label) 가져오는 법

## ProjectName: 05-DemoCalculator
1. Decimal 클래스
2. StringBuilder 클래스

## ProjectName: 06-WebSocketConnection
1. 웹소켓 연결

## ProjectName: 07-SetTimeGenerateFile
1. 지정된시간 파일생성 프로그램
2. 프로젝트 내부 README파일 참조

## ProjectName: 08-SetTimeGenerateFile2
1. 07번 프로젝트 단점 보안 프로젝트
2. 제작중