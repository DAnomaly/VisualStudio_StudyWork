﻿namespace SetTimeGenerateFile2
{
    public partial class RegistForm : Form
    {
        public RegistForm()
        {
            InitializeComponent();
        }
    }
}
