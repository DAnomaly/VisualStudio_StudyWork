﻿namespace _06_WebSocketConnection
{
    class Program
    {
        static void Main(string[] args)
        {

            new ConnectionManager("127.0.0.1", 1818);

            while (true)
            {

            }

        }
    }
}
